// truthy and falsy values 

// falsy values 


// false
// ""
// null 
// undefined
// 0