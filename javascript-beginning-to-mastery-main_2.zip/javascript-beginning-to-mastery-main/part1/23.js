// for loop example 

let total = 0;

let num = 100;

for(let i = 1; i<=num; i++){
    total = total + i;
}

console.log(total);