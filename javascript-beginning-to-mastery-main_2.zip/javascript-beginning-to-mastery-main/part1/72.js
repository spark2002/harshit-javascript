// console.log(window);
// "use strict";
// function myFunc(){
    
//     console.log(this);
// }
// myFunc();