// select element using get element by id
 
const mainHeading = document.getElementById("main-heading");
console.log(mainHeading);