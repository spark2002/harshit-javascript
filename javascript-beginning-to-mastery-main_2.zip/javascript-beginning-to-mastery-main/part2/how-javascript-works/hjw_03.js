
console.log(myFunction);

var myFunction = function(){
    console.log("this is my function");
}

console.log(myFunction);
